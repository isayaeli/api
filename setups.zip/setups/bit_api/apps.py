from django.apps import AppConfig


class BitApiConfig(AppConfig):
    name = 'bit_api'
